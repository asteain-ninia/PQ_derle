svg_peirce_quincuncial_v6_polygonize.py

概要
- 分高面をラスタ輪郭化ではなく、投影した分高面境界線から polygonize で面再構成する版。
- 文字は text のまま位置だけ投影。
- 境界線・経緯線はベクタのまま投影。
- 分高面の色は、元SVGの fill-only ラスタを高解像度で作って面の代表点を逆変換し、色判定する。

基本例
python svg_peirce_quincuncial_v6_polygonize.py "イラレ出界図.svg" --outdir out_poly --lon0-list 81

10度刻み一括
python svg_peirce_quincuncial_v6_polygonize.py "イラレ出界図.svg" --outdir out_poly_all --lon0-start 0 --lon0-end 350 --lon0-step 10 --combined-only

高画質寄り
python svg_peirce_quincuncial_v6_polygonize.py "イラレ出界図.svg" --outdir out_poly_hq --lon0-list 81,171,261,351 --source-raster-width 12000 --fill-max-seg 1.5 --fill-curve-steps 48 --frame-edge-steps 2400 --snap-grid 0.02 --face-min-area 0.01 --allow-huge-images

主な引数
--source-raster-width
  面の色判定用に元SVGを一度PNG化するときの横幅。大きいほど分類が安定する。

--fill-max-seg
  分高面境界をサンプリングするときの最大線分長。小さいほどシャープだが遅い。

--fill-curve-steps
  ベジェ最低分割数。小さすぎると角が鈍る。

--frame-edge-steps
  外枠の1辺あたりサンプル数。大きいほど外周が安定。

--snap-grid
  polygonize 前のスナップ格子。小さすぎると線が噛み合わず面が壊れやすい。大きすぎると形が鈍る。
  まずは 0.02〜0.05 推奨。

--face-min-area
  面再構成後に捨てる最小面積。小さくすると小島を残しやすい。

おすすめ初期値
- 速度重視: --source-raster-width 6000 --fill-max-seg 4 --fill-curve-steps 20 --frame-edge-steps 1440 --snap-grid 0.05 --face-min-area 0.05
- バランス: --source-raster-width 10000 --fill-max-seg 2.5 --fill-curve-steps 32 --frame-edge-steps 1800 --snap-grid 0.03 --face-min-area 0.02
- 高画質: --source-raster-width 12000 --fill-max-seg 1.5 --fill-curve-steps 48 --frame-edge-steps 2400 --snap-grid 0.02 --face-min-area 0.01 --allow-huge-images

注意
- この版は「分高面の境界線」を頼りに面を再構成する。ラスタ輪郭化より角が立ちやすい。
- それでも元ベジェを完全厳密に保つものではない。特異点近傍ではサンプリング密度と snap-grid の影響を受ける。
