SVG → Peirce Quincuncial 変換スクリプト
=====================================

同梱ファイル
------------
- svg_peirce_quincuncial.py
  元の正距円筒 SVG を Peirce Quincuncial に変換する本体。
  地図本体は path 化して変換、文字は text のまま残し、位置だけ投影します。
- pq_test4/
  lon_0=25 での試し出力（combined / map / text）

前提
----
- Python 3.10+
- pyproj
- lxml
- fontTools

インストール例
--------------
py -m pip install pyproj lxml fonttools

基本コマンド
------------
1) lon_0=25 を 1 つだけ出す
py svg_peirce_quincuncial.py "イラレ出界図.svg" --outdir out --lon0-list 25

2) 0,10,20,...,350 を全部出す
py svg_peirce_quincuncial.py "イラレ出界図.svg" --outdir out_all

3) combined だけにして軽く回す
py svg_peirce_quincuncial.py "イラレ出界図.svg" --outdir out_all --combined-only

出力内容
--------
lon_0 ごとに次を出します。
- *_combined.svg   地図 + 文字
- *_map.svg        地図だけ
- *_text.svg       文字だけ
- manifest.csv     出力一覧

今回のファイルに対する前提
------------------------
- 最大の 2:1 の rect を地図枠として自動認識します。
- その枠を lon=-180..180, lat=90..-90 の正距円筒として解釈します。
- 文字は非線形ワープしません。アンカー位置だけ投影します。
  なので Illustrator で後から少し動かす前提です。

よく使う調整
------------
- 特異点の位置を変えたい: --lon0-list 25 または --lon0-start 0 --lon0-end 350 --lon0-step 10
- 線をもっと滑らかにしたい: --max-seg 6 --curve-steps 16
- 出力を軽くしたい: --max-seg 12 --curve-steps 8
- 地図枠の自動認識を変えたい: --frame x0,y0,x1,y1

Illustrator での使い方
----------------------
- まず *_combined.svg を見て、良さそうな lon_0 を決める
- 本番は *_map.svg と *_text.svg を同じドキュメントに配置
- 文字は text のままなので、位置だけ微調整する

注意
----
- 地図本体のパスは投影のために折れ線へ近似しています。
- 投影の切れ目をまたぐ図形は、場所によっては分割されます。
- かなり Illustrator 由来の SVG を想定してありますが、別ファイルでは --frame 調整が必要なことがあります。
